# -*- coding: utf-8 -*-

from __future__ import absolute_import


__all__ = ("main",)


def main():
    from lyricli.console import main
    main()


if __name__ == "__main__":
    main()