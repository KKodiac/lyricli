import requests

def lyrics():
    ...