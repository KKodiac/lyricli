# Lyricli

터미널에서 원하는 가사를 보여줍니다. 

## Resources 
 - Homepage: [https://github.com/KKodiac/lyricli](https://github.com/KKodiac/lyricli)
 - Issues: [https://github.com/KKodiac/lyricli/issues](https://github.com/KKodiac/lyricli/issues)
 - Python Package: []

## Requirements
 - Python 3.6+

## Installation 
 
## Usage

## License

Contributor [Sean Hong](https://github.com/KKodiac)

Licensed under MIT License 
